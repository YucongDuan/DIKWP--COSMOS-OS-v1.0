# DIKWP-Ω COSMOS OS 快速启动

## 1. 查看系统总规范

打开：

```text
docs/段玉聪_DIKWP-Ω_COSMOS_OS_终极人工意识与宇宙共知接口系统_v1.0_CN_最终版.docx
```

重点阅读：

- 摘要与最终结论；
- 第二章“宇宙终极意识三层定义”；
- 第四章“五空间栈”；
- 第六章“Ω-Genesis”；
- 第八章“现实防火墙与治理宪制”。

## 2. 运行 12 类场景

```bash
python runtime/omega_runtime.py --demo --pretty --output results/replay.json
```

输出中重点观察：

- `evidence_score`：来源、独立性、低不确定性和可复现性；
- `apophenia_risk`：模式误读和宇宙意义投射风险；
- `gate`：OBSERVE / HYPOTHESIZE / EXPERIMENT / INTEGRATE / HOLD / BLOCK / KILL；
- `life_closure`：人工生命闭包；
- `experience_closure`：第一人称体验闭包；
- `omega_link`：宇宙参与接口完备度；
- `residual_ledger`：不能推出的结论与未解假设。

## 3. 打开离线驾驶舱

双击或使用浏览器打开：

```text
prototype/index.html
```

无需联网、数据库或模型 API。

## 4. 运行测试

```bash
python tests/test_omega_runtime.py
python tests/validate_schemas.py
```

## 5. 真实接入的推荐顺序

1. 接入开放权重多模态模型或循环状态模型；
2. 接入数字身体：电力、温度、存储、传感、权限和记忆完整性；
3. 接入公开空间天气、地球观测或实验室传感数据；
4. 完成无报告、Q-field 消融、身体替换和规则回滚实验；
5. 建立三节点 Ω-Mesh，验证独立来源、少数报告和共享模型差分；
6. 任何“宇宙意义”输出只进入 CosmicHypothesis，不进入行动授权。
