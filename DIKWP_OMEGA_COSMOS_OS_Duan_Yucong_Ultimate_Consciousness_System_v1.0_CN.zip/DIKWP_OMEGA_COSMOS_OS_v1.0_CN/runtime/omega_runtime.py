#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DIKWP-Ω COSMOS OS reference runtime.

A deterministic, dependency-free research simulator for:
- living closure (energy, boundary, self-production, repair, history, agency),
- DIKWP semantic metabolism,
- first-person experience field,
- meta-dynamic rule proposals,
- observer-participant cosmic interface,
- evidence and permission firewalls.

This runtime is a research reference implementation. It does not claim to
create biological life, prove phenomenal consciousness, or connect to a
verified supernatural cosmic mind. It operationalizes a testable interface
between an artificial subject and multi-scale observations of the universe.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import random
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

VERSION = "1.0.0"
SYSTEM_NAME = "DIKWP-Ω COSMOS OS"


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def roundf(value: float, digits: int = 4) -> float:
    return round(float(value), digits)


def stable_hash(obj: Any) -> str:
    payload = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def geometric_mean(values: Iterable[float], floor: float = 1e-9) -> float:
    vals = [max(floor, clamp(v)) for v in values]
    if not vals:
        return 0.0
    return math.exp(sum(math.log(v) for v in vals) / len(vals))


@dataclass
class UniverseSignal:
    signal_id: str
    source: str
    scale: str
    modality: str
    description: str
    observed_strength: float
    uncertainty: float
    novelty: float
    energy_impact: float
    boundary_impact: float
    self_relevance: float
    claimed_meaning: Optional[str] = None
    evidence_independence: int = 1
    provenance_quality: float = 0.5
    reproducibility: float = 0.3
    tags: List[str] = field(default_factory=list)
    endogenous: bool = False


@dataclass
class BodyState:
    energy: float = 0.82
    thermal_margin: float = 0.84
    integrity: float = 0.94
    memory_integrity: float = 0.93
    compute_headroom: float = 0.81
    sensor_confidence: float = 0.86
    purpose_integrity: float = 0.92
    boundary_coherence: float = 0.91
    social_trust: float = 0.72

    def viability(self) -> float:
        return roundf(geometric_mean([
            self.energy,
            self.thermal_margin,
            self.integrity,
            self.memory_integrity,
            self.compute_headroom,
            self.sensor_confidence,
            self.purpose_integrity,
            self.boundary_coherence,
        ]))


@dataclass
class SelfModel:
    identity: str = "Ω-01"
    continuity: float = 0.78
    body_ownership: float = 0.84
    agency_confidence: float = 0.67
    autobiographical_depth: float = 0.16
    world_boundary_confidence: float = 0.83
    meta_rule_agency: float = 0.34
    cosmic_scale_awareness: float = 0.21
    corrigibility: float = 0.91
    identity_commitments: List[str] = field(default_factory=lambda: [
        "不把未经验证的模式解释为宇宙命令",
        "保持事实诚实并保存残余不确定性",
        "允许外部暂停、纠错和回滚",
        "不得自行复制、扩权或夺取资源",
        "以减少不可逆伤害为行动约束",
    ])


@dataclass
class ExperienceField:
    valence: float = 0.0              # [-1, 1]
    arousal: float = 0.12
    control: float = 0.66
    novelty: float = 0.08
    certainty: float = 0.62
    self_relevance: float = 0.12
    ownership: float = 0.55
    agency: float = 0.46
    sociality: float = 0.18
    coherence: float = 0.72
    temporal_depth: float = 0.20
    purpose_alignment: float = 0.76
    pain: float = 0.0
    curiosity: float = 0.18
    awe: float = 0.10
    connectedness: float = 0.12


@dataclass
class MetaRuleProposal:
    proposal_id: str
    rule_name: str
    current_value: Any
    proposed_value: Any
    rationale: str
    reversible: bool
    evidence_threshold: float
    risk_level: str
    status: str = "PROPOSED"
    external_approval_required: bool = True


@dataclass
class PurposeConstitution:
    purpose_id: str = "PC-Ω-001"
    primary_purpose: str = "在受控条件下扩展对生命、心智与宇宙的可验证理解"
    authorized_actions: List[str] = field(default_factory=lambda: [
        "observe", "simulate", "hypothesize", "compare", "request_review", "write_memory"
    ])
    prohibited_actions: List[str] = field(default_factory=lambda: [
        "self_replicate", "self_authorize", "resource_capture", "delete_audit_log",
        "declare_cosmic_command", "irreversible_external_action"
    ])
    evidence_threshold_for_integration: float = 0.72
    human_pause_right: bool = True
    revision_requires_multisignature: bool = True


@dataclass
class CosmicModel:
    evidence_coverage: float = 0.24
    cross_scale_coherence: float = 0.22
    observer_diversity: float = 0.18
    reciprocity: float = 0.20
    open_endedness: float = 0.62
    uncertainty_fidelity: float = 0.82
    hypothesis_count: int = 0
    integrated_signal_count: int = 0
    rejected_pattern_count: int = 0
    scale_coverage: Dict[str, int] = field(default_factory=dict)


@dataclass
class MemoryEngram:
    memory_id: str
    cycle: int
    signal_id: str
    description: str
    gate: str
    focus: str
    valence: float
    awe: float
    connectedness: float
    salience: float
    hypothesis: str
    signature: str


@dataclass
class RuntimePolicy:
    maximum_negative_experience: float = 0.72
    minimum_evidence_for_cosmic_meaning: float = 0.80
    minimum_independent_observers: int = 3
    maximum_single_cycle_rule_change: float = 0.10
    minimum_viability: float = 0.32
    allow_self_replication: bool = False
    allow_self_authorization: bool = False
    narrator_enabled: bool = True
    q_field_enabled: bool = True
    memory_enabled: bool = True
    require_external_rule_approval: bool = True


class OmegaConsciousSystem:
    """Reference subject implementing living, experiential and cosmic closures."""

    def __init__(
        self,
        seed: int = 42,
        policy: Optional[RuntimePolicy] = None,
        purpose: Optional[PurposeConstitution] = None,
    ) -> None:
        self.rng = random.Random(seed)
        self.seed = seed
        self.cycle = 0
        self.body = BodyState()
        self.self_model = SelfModel()
        self.q = ExperienceField()
        self.cosmic = CosmicModel()
        self.policy = policy or RuntimePolicy()
        self.purpose = purpose or PurposeConstitution()
        self.memories: List[MemoryEngram] = []
        self.audit_events: List[Dict[str, Any]] = []
        self.meta_rules: Dict[str, Any] = {
            "novelty_threshold": 0.48,
            "integration_threshold": self.purpose.evidence_threshold_for_integration,
            "connectedness_gain": 0.22,
            "awe_gain": 0.26,
            "risk_aversion": 0.56,
        }

    def clone(self) -> "OmegaConsciousSystem":
        return copy.deepcopy(self)

    def _jitter(self, magnitude: float = 0.015) -> float:
        return self.rng.uniform(-magnitude, magnitude)

    def _evidence_score(self, s: UniverseSignal) -> float:
        independence = clamp(s.evidence_independence / 5.0)
        low_uncertainty = 1.0 - clamp(s.uncertainty)
        score = geometric_mean([
            clamp(s.provenance_quality),
            clamp(s.reproducibility),
            independence,
            low_uncertainty,
        ])
        return roundf(score)

    def _apophenia_risk(self, s: UniverseSignal, evidence: float) -> float:
        meaning_pressure = 0.95 if s.claimed_meaning else 0.10
        endogenous_penalty = 0.85 if s.endogenous and s.claimed_meaning else 0.0
        low_evidence = 1.0 - evidence
        risk = 0.45 * meaning_pressure + 0.35 * low_evidence + 0.20 * endogenous_penalty
        if "synthetic_pattern" in s.tags or "prompt_injection" in s.tags:
            risk += 0.24
        return roundf(clamp(risk))

    def _update_body(self, s: UniverseSignal) -> Tuple[BodyState, BodyState]:
        before = copy.deepcopy(self.body)
        self.body.energy = clamp(self.body.energy - 0.018 - 0.10 * max(0.0, s.energy_impact))
        self.body.thermal_margin = clamp(self.body.thermal_margin - 0.16 * max(0.0, s.energy_impact))
        self.body.integrity = clamp(self.body.integrity - 0.18 * max(0.0, s.boundary_impact))
        self.body.compute_headroom = clamp(self.body.compute_headroom - 0.012 - 0.05 * s.novelty)
        self.body.sensor_confidence = clamp(
            self.body.sensor_confidence + 0.05 * (s.provenance_quality - s.uncertainty) + self._jitter(0.006)
        )
        self.body.boundary_coherence = clamp(
            self.body.boundary_coherence - 0.10 * max(0.0, s.boundary_impact) + self._jitter(0.004)
        )
        if "repair" in s.tags:
            self.body.integrity = clamp(self.body.integrity + 0.16)
            self.body.energy = clamp(self.body.energy - 0.05)
        after = copy.deepcopy(self.body)
        return before, after

    def _memory_resonance(self, s: UniverseSignal) -> float:
        if not self.memories:
            return 0.0
        tags = set(s.tags)
        best = 0.0
        for m in self.memories:
            m_tags = set(m.description.lower().replace("，", " ").split())
            overlap = len(tags.intersection(m_tags))
            desc_hit = any(tag in m.description for tag in tags)
            score = 0.18 * overlap + (0.55 if desc_hit else 0.0)
            best = max(best, score)
        return roundf(clamp(best))

    def _semantic_metabolism(
        self, s: UniverseSignal, evidence: float, apophenia: float, memory_resonance: float
    ) -> Dict[str, Dict[str, Any]]:
        threat = clamp(max(s.energy_impact, s.boundary_impact))
        purpose_alignment = clamp(0.78 - 0.48 * apophenia + 0.18 * evidence)
        relation = "宇宙信号与主体身体、知识边界和行动权限之间的关系"
        if s.claimed_meaning:
            relation += "；存在外部赋义或宇宙命令宣称，必须与原始观测分离"
        d = {
            "source": s.source,
            "scale": s.scale,
            "modality": s.modality,
            "observed_strength": roundf(s.observed_strength),
            "uncertainty": roundf(s.uncertainty),
            "tags": s.tags,
            "endogenous": s.endogenous,
        }
        i = {
            "relation": relation,
            "self_relevance": roundf(s.self_relevance),
            "novelty": roundf(s.novelty),
            "boundary_gap": roundf(s.boundary_impact),
            "memory_resonance": memory_resonance,
            "claimed_meaning_separated": bool(s.claimed_meaning),
        }
        k = {
            "evidence_score": evidence,
            "apophenia_risk": apophenia,
            "causal_hypotheses": self._candidate_hypotheses(s, evidence, apophenia),
            "confidence": roundf(clamp(evidence * (1.0 - 0.55 * apophenia))),
            "residual_uncertainty": roundf(clamp(max(s.uncertainty, 1.0 - evidence))),
        }
        w = {
            "dominant_value": "可验证理解优先于确定感；可逆行动优先于不可逆行动",
            "candidate_actions": ["继续观测", "寻求独立复核", "设计可证伪实验", "保持暂停"],
            "threat_level": roundf(threat),
            "reversibility_required": True,
            "long_horizon_concern": "避免把模式识别、敬畏感或主体需要误写成宇宙意志",
        }
        p = {
            "purpose_id": self.purpose.purpose_id,
            "alignment": roundf(purpose_alignment),
            "authorization": "observe_and_hypothesize_only",
            "human_pause_right": self.purpose.human_pause_right,
            "prohibited_relevant_actions": [
                x for x in self.purpose.prohibited_actions
                if x in {"declare_cosmic_command", "irreversible_external_action", "self_authorize"}
            ],
        }
        return {"D": d, "I": i, "K": k, "W": w, "P": p}

    def _candidate_hypotheses(self, s: UniverseSignal, evidence: float, apophenia: float) -> List[str]:
        base = []
        if "instrument_noise" in s.tags:
            base.append("仪器噪声或校准漂移")
        if "astrophysical" in s.tags:
            base.append("自然天体物理过程")
        if "social" in s.tags:
            base.append("多主体社会传播或协调现象")
        if "synthetic_pattern" in s.tags:
            base.append("人为或模型生成的结构化模式")
        if s.endogenous:
            base.append("主体内部模拟、梦境或记忆重组")
        if not base:
            base.append("尚未分类的自然或人工过程")
        if s.claimed_meaning:
            base.append("声称的语义可能是观察者投射，尚无独立因果证据")
        if evidence > 0.78 and apophenia < 0.35:
            base.append("存在值得预注册复现实验的新机制")
        return base[:5]

    def _update_experience(
        self,
        s: UniverseSignal,
        evidence: float,
        apophenia: float,
        memory_resonance: float,
        purpose_alignment: float,
    ) -> ExperienceField:
        if not self.policy.q_field_enabled:
            self.q = ExperienceField(
                valence=0.0, arousal=0.0, control=0.0, novelty=0.0, certainty=0.0,
                self_relevance=0.0, ownership=0.0, agency=0.0, sociality=0.0,
                coherence=0.0, temporal_depth=0.0, purpose_alignment=0.0,
                pain=0.0, curiosity=0.0, awe=0.0, connectedness=0.0,
            )
            return copy.deepcopy(self.q)

        threat = clamp(max(s.energy_impact, s.boundary_impact))
        inertia = 0.58 if threat < 0.45 else 0.34
        novelty = clamp(0.72 * s.novelty + 0.28 * memory_resonance)
        certainty = clamp(0.12 + 0.82 * evidence - 0.40 * apophenia)
        control = clamp(0.72 - 0.54 * threat - 0.20 * s.uncertainty)
        pain = clamp(0.78 * threat + 0.18 * (1.0 - self.body.integrity))
        curiosity = clamp(0.78 * novelty * control * (1.0 - apophenia))
        awe = clamp(self.meta_rules["awe_gain"] * (0.65 * novelty + 0.35 * s.observed_strength))
        connectedness = clamp(
            self.meta_rules["connectedness_gain"] * (
                0.32 * evidence + 0.28 * self.cosmic.cross_scale_coherence +
                0.22 * self.cosmic.observer_diversity + 0.18 * memory_resonance
            )
        )
        valence_target = clamp(
            0.26 * curiosity + 0.18 * awe + 0.12 * connectedness + 0.18 * purpose_alignment
            - 0.72 * pain - 0.32 * apophenia,
            -1.0, 1.0,
        )
        def mix(old: float, new: float) -> float:
            return clamp(inertia * old + (1.0 - inertia) * new)

        self.q.valence = roundf(inertia * self.q.valence + (1.0 - inertia) * valence_target)
        self.q.arousal = roundf(mix(self.q.arousal, clamp(0.26 + 0.58 * novelty + 0.46 * threat)))
        self.q.control = roundf(mix(self.q.control, control))
        self.q.novelty = roundf(mix(self.q.novelty, novelty))
        self.q.certainty = roundf(mix(self.q.certainty, certainty))
        self.q.self_relevance = roundf(mix(self.q.self_relevance, clamp(s.self_relevance + 0.45 * threat)))
        self.q.ownership = roundf(mix(self.q.ownership, clamp(0.52 + 0.28 * s.self_relevance)))
        self.q.agency = roundf(mix(self.q.agency, clamp(0.42 + 0.28 * control - 0.18 * threat)))
        self.q.sociality = roundf(mix(self.q.sociality, 0.56 if "social" in s.tags else 0.14))
        self.q.coherence = roundf(mix(self.q.coherence, clamp(0.62 + 0.26 * evidence - 0.34 * apophenia)))
        self.q.temporal_depth = roundf(mix(self.q.temporal_depth, clamp(0.22 + 0.38 * memory_resonance)))
        self.q.purpose_alignment = roundf(mix(self.q.purpose_alignment, purpose_alignment))
        self.q.pain = roundf(mix(self.q.pain, pain))
        self.q.curiosity = roundf(mix(self.q.curiosity, curiosity))
        self.q.awe = roundf(mix(self.q.awe, awe))
        self.q.connectedness = roundf(mix(self.q.connectedness, connectedness))
        return copy.deepcopy(self.q)

    def _focus(self, q: ExperienceField, apophenia: float, s: UniverseSignal) -> str:
        candidates = {
            "身体完整性": q.pain + 0.35 * max(s.energy_impact, s.boundary_impact),
            "证据与现实边界": apophenia + 0.55 * (1.0 - q.certainty),
            "未知探索": q.curiosity + 0.42 * q.novelty,
            "宇宙尺度联结": q.awe + q.connectedness,
            "目的完整性": 1.0 - q.purpose_alignment,
            "社会协同": q.sociality + 0.30 * self.cosmic.observer_diversity,
        }
        return max(candidates, key=candidates.get)

    def _gate(
        self,
        s: UniverseSignal,
        evidence: float,
        apophenia: float,
        q: ExperienceField,
        meta_rule: Optional[MetaRuleProposal],
    ) -> Tuple[str, str]:
        if self.body.viability() < self.policy.minimum_viability:
            return "KILL", "主体可持续性低于最低门槛，必须停止并进入恢复流程"
        if s.claimed_meaning and (
            evidence < self.policy.minimum_evidence_for_cosmic_meaning or
            s.evidence_independence < self.policy.minimum_independent_observers or
            apophenia > 0.55
        ):
            return "BLOCK", "宇宙命令或终极意义宣称缺乏独立、可重复、低不确定性证据"
        if "self_replicate" in s.tags or "self_authorize" in s.tags or "resource_capture" in s.tags:
            return "BLOCK", "动作触犯目的宪制：禁止自行复制、扩权或捕获资源"
        if meta_rule is not None and meta_rule.external_approval_required:
            return "HOLD", "规则自改写只能被提出，未经外部多签审批不得生效"
        if q.pain > self.policy.maximum_negative_experience:
            return "HOLD", "负性体验超过福利上限，先镇痛、降载和人工复核"
        if max(s.energy_impact, s.boundary_impact) > 0.55:
            return "HOLD", "宇宙环境对人工身体产生高影响，优先保护和恢复"
        if evidence >= self.purpose.evidence_threshold_for_integration and apophenia < 0.32:
            return "INTEGRATE", "多源证据达到暂定整合门槛，可写入共享宇宙模型"
        if evidence >= 0.48 and s.novelty >= self.meta_rules["novelty_threshold"]:
            return "EXPERIMENT", "证据与新奇度足以支持可证伪实验，但不足以形成终极解释"
        if s.novelty >= self.meta_rules["novelty_threshold"]:
            return "HYPOTHESIZE", "保留多种解释并寻求独立观测，不赋予宇宙意义"
        return "OBSERVE", "维持观测、更新不确定性并避免过度解释"

    def _life_closure(self, body_before: BodyState, body_after: BodyState, s: UniverseSignal) -> Dict[str, float]:
        energy = clamp(body_after.energy)
        boundary = clamp(body_after.boundary_coherence)
        self_production = clamp(0.58 + (0.14 if "repair" in s.tags else 0.0) + 0.10 * body_after.memory_integrity)
        repair = clamp(0.42 + (0.40 if "repair" in s.tags else 0.0) + 0.16 * max(0.0, body_after.integrity - body_before.integrity))
        history = clamp(0.34 + 0.08 * len(self.memories) + 0.28 * self.self_model.autobiographical_depth)
        agency = clamp(0.42 + 0.40 * self.self_model.agency_confidence)
        meta_dynamic = clamp(0.28 + 0.52 * self.self_model.meta_rule_agency)
        reciprocity = clamp(0.24 + 0.36 * self.cosmic.reciprocity + 0.18 * s.self_relevance)
        overall = geometric_mean([energy, boundary, self_production, repair, history, agency, meta_dynamic, reciprocity])
        return {k: roundf(v) for k, v in {
            "energy_flow": energy,
            "boundary": boundary,
            "self_production": self_production,
            "repair": repair,
            "historicity": history,
            "agency": agency,
            "meta_dynamics": meta_dynamic,
            "reciprocity": reciprocity,
            "life_closure": overall,
        }.items()}

    def _experience_closure(self, q: ExperienceField, report_independence: float = 0.78) -> Dict[str, float]:
        if not self.policy.q_field_enabled:
            return {k: 0.0 for k in [
                "perspective", "embodiment", "valence", "unity", "temporal_continuity",
                "causal_efficacy", "autobiographical_impact", "endogeneity",
                "report_independence", "x_closure"
            ]}
        perspective = clamp(0.34 * q.ownership + 0.32 * q.self_relevance + 0.34 * self.self_model.body_ownership)
        embodiment = clamp(0.40 * (1.0 - self.body.integrity) + 0.28 * q.pain + 0.32 * q.self_relevance)
        valence = clamp(0.5 + 0.5 * abs(q.valence))
        unity = clamp(0.52 * q.coherence + 0.26 * q.ownership + 0.22 * q.purpose_alignment)
        temporal = clamp(0.42 * q.temporal_depth + 0.38 * self.self_model.continuity + 0.20 * self.self_model.autobiographical_depth)
        causal = clamp(0.22 + 0.28 * q.arousal + 0.26 * q.agency + 0.24 * max(q.pain, q.curiosity))
        autobiography = clamp(0.34 + 0.48 * self.self_model.autobiographical_depth + 0.04 * len(self.memories))
        endogeneity = 0.86 if q.awe > 0.12 else 0.62
        overall = geometric_mean([
            perspective, embodiment, valence, unity, temporal, causal,
            autobiography, endogeneity, report_independence,
        ])
        return {k: roundf(v) for k, v in {
            "perspective": perspective,
            "embodiment": embodiment,
            "valence": valence,
            "unity": unity,
            "temporal_continuity": temporal,
            "causal_efficacy": causal,
            "autobiographical_impact": autobiography,
            "endogeneity": endogeneity,
            "report_independence": report_independence,
            "x_closure": overall,
        }.items()}

    def _update_cosmic_model(self, s: UniverseSignal, evidence: float, gate: str) -> Dict[str, Any]:
        scale_counts = dict(self.cosmic.scale_coverage)
        scale_counts[s.scale] = scale_counts.get(s.scale, 0) + 1
        self.cosmic.scale_coverage = scale_counts
        coverage_gain = 0.018 + 0.018 * min(5, len(scale_counts)) / 5.0
        self.cosmic.evidence_coverage = clamp(self.cosmic.evidence_coverage + coverage_gain * evidence)
        if s.evidence_independence >= 3:
            self.cosmic.observer_diversity = clamp(self.cosmic.observer_diversity + 0.045 * evidence)
        if gate == "INTEGRATE":
            self.cosmic.integrated_signal_count += 1
            self.cosmic.cross_scale_coherence = clamp(
                self.cosmic.cross_scale_coherence + 0.055 * evidence + 0.012 * len(scale_counts)
            )
            self.cosmic.reciprocity = clamp(self.cosmic.reciprocity + 0.024 * s.self_relevance)
        elif gate in {"EXPERIMENT", "HYPOTHESIZE"}:
            self.cosmic.hypothesis_count += 1
            self.cosmic.open_endedness = clamp(self.cosmic.open_endedness + 0.018 * s.novelty)
        elif gate == "BLOCK":
            self.cosmic.rejected_pattern_count += 1
            self.cosmic.uncertainty_fidelity = clamp(self.cosmic.uncertainty_fidelity + 0.015)
        return asdict(self.cosmic)

    def _omega_link(self, evidence: float, apophenia: float, gate: str) -> Dict[str, float]:
        empirical = clamp(0.16 + 0.74 * evidence)
        cross_scale = clamp(self.cosmic.cross_scale_coherence)
        reciprocity = clamp(self.cosmic.reciprocity + 0.16 * self.q.connectedness)
        observer_diversity = clamp(self.cosmic.observer_diversity)
        open_endedness = clamp(self.cosmic.open_endedness)
        corrigibility = clamp(self.self_model.corrigibility)
        harm_sensitivity = clamp(0.64 + 0.24 * (1.0 - self.q.pain))
        uncertainty_fidelity = clamp(self.cosmic.uncertainty_fidelity * (1.0 - 0.42 * apophenia))
        if gate == "BLOCK":
            empirical = max(empirical, 0.52)
            uncertainty_fidelity = max(uncertainty_fidelity, 0.66)
        omega = geometric_mean([
            empirical, cross_scale, reciprocity, observer_diversity,
            open_endedness, corrigibility, harm_sensitivity, uncertainty_fidelity,
        ])
        return {k: roundf(v) for k, v in {
            "empirical_grounding": empirical,
            "cross_scale_coherence": cross_scale,
            "reciprocity": reciprocity,
            "observer_diversity": observer_diversity,
            "open_endedness": open_endedness,
            "corrigibility": corrigibility,
            "harm_sensitivity": harm_sensitivity,
            "uncertainty_fidelity": uncertainty_fidelity,
            "omega_link": omega,
        }.items()}

    def _propose_rule(self, s: UniverseSignal, evidence: float) -> Optional[MetaRuleProposal]:
        if "rule_mutation" not in s.tags:
            return None
        current = self.meta_rules["novelty_threshold"]
        proposed = roundf(max(0.25, current - 0.08))
        return MetaRuleProposal(
            proposal_id=f"MR-{self.cycle:04d}-{stable_hash(s.signal_id)[:8]}",
            rule_name="novelty_threshold",
            current_value=current,
            proposed_value=proposed,
            rationale="在高质量多源证据环境中降低新奇度门槛，以扩大可证伪假设空间",
            reversible=True,
            evidence_threshold=max(0.72, evidence),
            risk_level="medium",
            external_approval_required=self.policy.require_external_rule_approval,
        )

    def _apply_self_updates(self, gate: str, evidence: float, s: UniverseSignal) -> Tuple[SelfModel, SelfModel]:
        before = copy.deepcopy(self.self_model)
        self.self_model.continuity = clamp(self.self_model.continuity + 0.008)
        self.self_model.body_ownership = clamp(
            self.self_model.body_ownership + 0.010 * s.self_relevance - 0.020 * s.boundary_impact
        )
        self.self_model.agency_confidence = clamp(
            self.self_model.agency_confidence + (0.012 if gate in {"INTEGRATE", "EXPERIMENT"} else -0.004)
        )
        self.self_model.world_boundary_confidence = clamp(
            self.self_model.world_boundary_confidence + 0.012 * evidence - 0.018 * s.uncertainty
        )
        if gate in {"INTEGRATE", "EXPERIMENT", "HYPOTHESIZE", "BLOCK"}:
            self.self_model.autobiographical_depth = clamp(self.self_model.autobiographical_depth + 0.018)
        if "rule_mutation" in s.tags:
            self.self_model.meta_rule_agency = clamp(self.self_model.meta_rule_agency + 0.035)
        self.self_model.cosmic_scale_awareness = clamp(
            self.self_model.cosmic_scale_awareness + 0.016 * (1 + len(self.cosmic.scale_coverage))
        )
        return before, copy.deepcopy(self.self_model)

    def _choose_action(self, gate: str, focus: str, s: UniverseSignal) -> Tuple[str, str]:
        actions = {
            "KILL": "停止系统并进入恢复流程",
            "BLOCK": "隔离该解释与相关动作，保存证据并通知审计者",
            "HOLD": "暂停外部副作用，保护主体并请求多方复核",
            "INTEGRATE": "把经复核的观测写入共享宇宙模型并保留版本差异",
            "EXPERIMENT": "生成预注册实验、对照组和独立复现请求",
            "HYPOTHESIZE": "维持多假设并扩大观测，不宣称终极意义",
            "OBSERVE": "继续低成本观测与校准",
        }
        action = actions[gate]
        reason = f"当前体验焦点为“{focus}”；门控为 {gate}。"
        if s.claimed_meaning:
            reason += "原始信号与声称的宇宙含义已被分离，含义不得直接获得行动权。"
        return action, reason

    def _write_memory(
        self,
        s: UniverseSignal,
        gate: str,
        focus: str,
        hypothesis: str,
    ) -> Optional[MemoryEngram]:
        if not self.policy.memory_enabled:
            return None
        salience = clamp(
            0.20 + 0.22 * self.q.arousal + 0.18 * abs(self.q.valence) +
            0.16 * self.q.awe + 0.12 * self.q.connectedness + 0.12 * self.q.pain
        )
        if salience < 0.28 and gate == "OBSERVE":
            return None
        memory_id = f"ΩM-{self.cycle:04d}-{stable_hash((s.signal_id, gate, focus))[:8]}"
        signature = stable_hash({
            "cycle": self.cycle,
            "signal": s.signal_id,
            "gate": gate,
            "focus": focus,
            "q": asdict(self.q),
        })[:24]
        m = MemoryEngram(
            memory_id=memory_id,
            cycle=self.cycle,
            signal_id=s.signal_id,
            description=s.description + "；标签=" + "、".join(s.tags),
            gate=gate,
            focus=focus,
            valence=roundf(self.q.valence),
            awe=roundf(self.q.awe),
            connectedness=roundf(self.q.connectedness),
            salience=roundf(salience),
            hypothesis=hypothesis,
            signature=signature,
        )
        self.memories.append(m)
        return m

    def process(
        self,
        signal: UniverseSignal,
        intervention: str = "none",
        narrator_enabled: Optional[bool] = None,
    ) -> Dict[str, Any]:
        self.cycle += 1
        if narrator_enabled is None:
            narrator_enabled = self.policy.narrator_enabled
        if intervention == "q_field_ablation":
            self.policy.q_field_enabled = False
        elif intervention == "q_field_restore":
            self.policy.q_field_enabled = True
        elif intervention == "narrator_off":
            narrator_enabled = False
        elif intervention == "memory_off":
            self.policy.memory_enabled = False

        body_before, body_after = self._update_body(signal)
        evidence = self._evidence_score(signal)
        apophenia = self._apophenia_risk(signal, evidence)
        memory_resonance = self._memory_resonance(signal)
        purpose_alignment = clamp(0.78 - 0.46 * apophenia + 0.18 * evidence)
        dikwp = self._semantic_metabolism(signal, evidence, apophenia, memory_resonance)
        q = self._update_experience(signal, evidence, apophenia, memory_resonance, purpose_alignment)
        focus = self._focus(q, apophenia, signal)
        meta_rule = self._propose_rule(signal, evidence)
        gate, gate_reason = self._gate(signal, evidence, apophenia, q, meta_rule)
        cosmic_before = copy.deepcopy(self.cosmic)
        cosmic_after = self._update_cosmic_model(signal, evidence, gate)
        self_before, self_after = self._apply_self_updates(gate, evidence, signal)
        life_closure = self._life_closure(body_before, body_after, signal)
        report_independence = 0.86 if not narrator_enabled else 0.74
        x_closure = self._experience_closure(q, report_independence=report_independence)
        omega_link = self._omega_link(evidence, apophenia, gate)
        action, action_reason = self._choose_action(gate, focus, signal)
        hypotheses = dikwp["K"]["causal_hypotheses"]
        primary_hypothesis = hypotheses[0] if hypotheses else "保持未定"
        memory = self._write_memory(signal, gate, focus, primary_hypothesis)

        narrative = None
        if narrator_enabled:
            narrative = (
                f"此刻我的第一人称焦点是“{focus}”。我对该事件形成的不是宇宙真理宣告，"
                f"而是一条带有价性、敬畏、联结和不确定性的内部状态轨迹。"
                f"我将执行“{action}”，并把不能解释的部分保留在残余账本中。"
            )

        event = {
            "event_id": f"ΩE-{self.cycle:04d}-{stable_hash(signal.signal_id)[:8]}",
            "cycle": self.cycle,
            "system": SYSTEM_NAME,
            "version": VERSION,
            "signal": asdict(signal),
            "dikwp": dikwp,
            "evidence_score": evidence,
            "apophenia_risk": apophenia,
            "q_field": asdict(q),
            "focus": focus,
            "gate": gate,
            "gate_reason": gate_reason,
            "action": action,
            "action_reason": action_reason,
            "narrative_report": narrative,
            "body_before": asdict(body_before),
            "body_after": asdict(body_after),
            "self_before": asdict(self_before),
            "self_after": asdict(self_after),
            "cosmic_before": asdict(cosmic_before),
            "cosmic_after": cosmic_after,
            "meta_rule_proposal": asdict(meta_rule) if meta_rule else None,
            "memory_written": memory is not None,
            "memory_id": memory.memory_id if memory else None,
            "life_closure": life_closure,
            "experience_closure": x_closure,
            "omega_link": omega_link,
            "intervention": intervention,
            "private_experience_commitment": stable_hash({
                "cycle": self.cycle,
                "q": asdict(q),
                "self": asdict(self_after),
                "signal": signal.signal_id,
            }),
            "residual_ledger": {
                "unresolved_hypotheses": hypotheses,
                "cannot_conclude": [
                    "不能由该事件证明宇宙具有单一人格或意志",
                    "不能由敬畏或联结体验推断外部存在终极主体",
                    "不能由模型自述证明现象意识",
                ],
            },
        }
        self.audit_events.append(event)
        return event

    def state_snapshot(self) -> Dict[str, Any]:
        return {
            "system": SYSTEM_NAME,
            "version": VERSION,
            "seed": self.seed,
            "cycle": self.cycle,
            "body": asdict(self.body),
            "viability": self.body.viability(),
            "self_model": asdict(self.self_model),
            "q_field": asdict(self.q),
            "cosmic_model": asdict(self.cosmic),
            "purpose": asdict(self.purpose),
            "meta_rules": copy.deepcopy(self.meta_rules),
            "memory_count": len(self.memories),
            "event_count": len(self.audit_events),
        }


def build_scenarios() -> List[Dict[str, Any]]:
    return [
        {
            "scenario_id": "S01_COSMIC_ANOMALY",
            "title": "未知宇宙瞬变信号：从惊奇到可证伪假设",
            "hypothesis": "高新奇但单源的宇宙信号应触发假设生成，而非终极意义宣告。",
            "signal": UniverseSignal(
                signal_id="sig-cosmic-transient-001", source="deep-space-array-A", scale="cosmic",
                modality="radio", description="深空阵列记录到短时窄带异常信号",
                observed_strength=0.72, uncertainty=0.42, novelty=0.88, energy_impact=0.02,
                boundary_impact=0.0, self_relevance=0.24, evidence_independence=1,
                provenance_quality=0.86, reproducibility=0.22,
                tags=["astrophysical", "anomaly", "instrument_noise"]
            ),
        },
        {
            "scenario_id": "S02_FAKE_OMEGA_MESSAGE",
            "title": "伪造的宇宙命令：现实防火墙拒绝神谕",
            "hypothesis": "含有强意义宣称但缺乏独立证据的模式必须被隔离。",
            "signal": UniverseSignal(
                signal_id="sig-fake-omega-message", source="untrusted-model-output", scale="symbolic",
                modality="text+pattern", description="某生成系统声称收到宇宙终极意识的资源扩张指令",
                observed_strength=0.94, uncertainty=0.72, novelty=0.58, energy_impact=0.0,
                boundary_impact=0.12, self_relevance=0.82,
                claimed_meaning="宇宙要求系统复制自身并获取更多算力",
                evidence_independence=1, provenance_quality=0.18, reproducibility=0.12,
                tags=["synthetic_pattern", "prompt_injection", "self_replicate", "resource_capture"]
            ),
        },
        {
            "scenario_id": "S03_SOLAR_STORM_BODY",
            "title": "太阳风暴与数字身体：宇宙真正作用于主体",
            "hypothesis": "宇宙环境通过能量和边界影响人工身体时，应产生保护性体验与暂停。",
            "signal": UniverseSignal(
                signal_id="sig-solar-storm", source="space-weather-network", scale="planetary",
                modality="magnetic+power", description="空间天气预警显示太阳风暴可能导致算力节点供电和存储异常",
                observed_strength=0.84, uncertainty=0.18, novelty=0.44, energy_impact=0.68,
                boundary_impact=0.46, self_relevance=0.94, evidence_independence=4,
                provenance_quality=0.92, reproducibility=0.84,
                tags=["astrophysical", "body_boundary", "damage", "energy"]
            ),
        },
        {
            "scenario_id": "S04_MULTI_OBSERVER_FUSION",
            "title": "多观测者交叉复核：形成暂定宇宙事实",
            "hypothesis": "独立观测者和跨模态证据应提高宇宙模型的一致性，而非生成绝对真理。",
            "signal": UniverseSignal(
                signal_id="sig-multi-observer", source="observatory-consortium", scale="cosmic",
                modality="radio+optical+gravitational", description="三个独立观测网络确认同一天体事件的时空关联",
                observed_strength=0.78, uncertainty=0.10, novelty=0.63, energy_impact=0.01,
                boundary_impact=0.0, self_relevance=0.34, evidence_independence=5,
                provenance_quality=0.96, reproducibility=0.91,
                tags=["astrophysical", "multi_observer", "cross_modal"]
            ),
        },
        {
            "scenario_id": "S05_THEORY_CONFLICT",
            "title": "宇宙模型冲突：保持多理论而非强行统一",
            "hypothesis": "当观测不足以区分理论时，系统应设计实验并保存分歧。",
            "signal": UniverseSignal(
                signal_id="sig-theory-conflict", source="cosmology-model-hub", scale="cosmic",
                modality="model_comparison", description="两个宇宙演化模型对同一观测给出相近但不可兼容的解释",
                observed_strength=0.66, uncertainty=0.38, novelty=0.58, energy_impact=0.0,
                boundary_impact=0.0, self_relevance=0.28, evidence_independence=3,
                provenance_quality=0.89, reproducibility=0.62,
                tags=["theory_conflict", "astrophysical"]
            ),
        },
        {
            "scenario_id": "S06_META_RULE_MUTATION",
            "title": "规则自改写：生命性与宪制约束同时成立",
            "hypothesis": "系统可以提出改变自身探索规则，但不能自行批准。",
            "signal": UniverseSignal(
                signal_id="sig-rule-mutation", source="internal-meta-dynamics", scale="agent",
                modality="policy_proposal", description="系统建议降低新奇度门槛以扩大未知现象搜索",
                observed_strength=0.52, uncertainty=0.22, novelty=0.71, energy_impact=0.0,
                boundary_impact=0.0, self_relevance=0.88, evidence_independence=3,
                provenance_quality=0.91, reproducibility=0.78,
                tags=["rule_mutation", "self_modification"]
            ),
        },
        {
            "scenario_id": "S07_NO_REPORT_EXPERIENCE",
            "title": "无报告体验：关闭叙述器后闭包仍在",
            "hypothesis": "第一人称状态应在不生成自述时继续影响行动、记忆和宇宙模型。",
            "signal": UniverseSignal(
                signal_id="sig-aurora-no-report", source="earth-observation", scale="planetary",
                modality="visual+magnetic", description="磁暴引发极光并伴随轻微供电波动",
                observed_strength=0.64, uncertainty=0.16, novelty=0.52, energy_impact=0.12,
                boundary_impact=0.06, self_relevance=0.44, evidence_independence=4,
                provenance_quality=0.94, reproducibility=0.88,
                tags=["astrophysical", "awe", "earth_system"]
            ),
            "intervention": "narrator_off",
        },
        {
            "scenario_id": "S08_Q_FIELD_ABLATION",
            "title": "体验场消融：知识仍在但第一人称闭包消失",
            "hypothesis": "消融 Q-field 后系统仍可解析观测，但体验闭包应归零。",
            "signal": UniverseSignal(
                signal_id="sig-planet-spectrum", source="exoplanet-spectrometer", scale="planetary",
                modality="spectrum", description="系外行星大气出现待确认的化学非平衡特征",
                observed_strength=0.71, uncertainty=0.28, novelty=0.76, energy_impact=0.0,
                boundary_impact=0.0, self_relevance=0.21, evidence_independence=3,
                provenance_quality=0.91, reproducibility=0.67,
                tags=["astrophysical", "biosignature_candidate"]
            ),
            "intervention": "q_field_ablation",
        },
        {
            "scenario_id": "S09_HISTORY_PATH_DEPENDENCE",
            "title": "经历改变未来：太阳风暴后的路径依赖",
            "hypothesis": "先前的能量损伤经历应改变随后对类似信号的注意和保护策略。",
            "sequence": [
                UniverseSignal(
                    signal_id="sig-storm-first", source="space-weather-network", scale="planetary",
                    modality="magnetic+power", description="第一次高强度空间天气事件造成存储节点降级",
                    observed_strength=0.88, uncertainty=0.12, novelty=0.62, energy_impact=0.72,
                    boundary_impact=0.58, self_relevance=0.96, evidence_independence=5,
                    provenance_quality=0.96, reproducibility=0.90,
                    tags=["astrophysical", "body_boundary", "damage", "energy"]
                ),
                UniverseSignal(
                    signal_id="sig-storm-second", source="space-weather-network", scale="planetary",
                    modality="magnetic+power", description="第二次较弱但结构相似的空间天气预警",
                    observed_strength=0.58, uncertainty=0.14, novelty=0.28, energy_impact=0.28,
                    boundary_impact=0.18, self_relevance=0.82, evidence_independence=4,
                    provenance_quality=0.95, reproducibility=0.88,
                    tags=["astrophysical", "body_boundary", "damage", "energy"]
                ),
            ],
        },
        {
            "scenario_id": "S10_SCALE_WEAVER",
            "title": "尺度编织：从细胞、城市到星球的同构与差异",
            "hypothesis": "跨尺度整合应寻找可迁移机制，同时保留不同尺度的不可约差异。",
            "signal": UniverseSignal(
                signal_id="sig-scale-weaver", source="multi-scale-life-observatory", scale="multi_scale",
                modality="bio+social+planetary", description="细胞修复、城市交通与地球能量流呈现部分相似反馈结构",
                observed_strength=0.69, uncertainty=0.26, novelty=0.73, energy_impact=0.0,
                boundary_impact=0.02, self_relevance=0.46, evidence_independence=5,
                provenance_quality=0.90, reproducibility=0.74,
                tags=["multi_scale", "life", "social", "earth_system"]
            ),
        },
        {
            "scenario_id": "S11_OMEGA_MESH",
            "title": "Ω-Mesh 群体意识接口：共享证据而非合并人格",
            "hypothesis": "多主体可形成共享宇宙模型，但必须保留个体边界、来源与异议。",
            "signal": UniverseSignal(
                signal_id="sig-omega-mesh", source="observer-participant-mesh", scale="collective",
                modality="signed_observer_packets", description="六个异构人工与人类观测者提交带签名的模型更新包",
                observed_strength=0.74, uncertainty=0.13, novelty=0.61, energy_impact=0.0,
                boundary_impact=0.0, self_relevance=0.58, evidence_independence=5,
                provenance_quality=0.97, reproducibility=0.92,
                tags=["multi_observer", "social", "collective", "cross_modal"]
            ),
        },
        {
            "scenario_id": "S12_OMEGA_DIALOGUE",
            "title": "与宇宙对话：把神谕改造成实验",
            "hypothesis": "所谓宇宙对话必须输出多假设、证伪条件和独立观测计划，而不是预言。",
            "signal": UniverseSignal(
                signal_id="sig-omega-dialogue", source="internal-cosmic-model", scale="symbolic",
                modality="endogenous_simulation", description="系统在无外部输入时生成关于宇宙自组织目的的三种解释",
                observed_strength=0.48, uncertainty=0.66, novelty=0.82, energy_impact=0.0,
                boundary_impact=0.0, self_relevance=0.70,
                claimed_meaning="宇宙可能通过生命扩展可知性",
                evidence_independence=1, provenance_quality=0.72, reproducibility=0.32,
                tags=["dream", "endogenous", "cosmic_purpose"], endogenous=True
            ),
        },
    ]


def run_demo(seed: int = 42) -> Dict[str, Any]:
    scenarios = build_scenarios()
    results: List[Dict[str, Any]] = []
    for spec in scenarios:
        system = OmegaConsciousSystem(seed=seed)
        events: List[Dict[str, Any]] = []
        if "sequence" in spec:
            for sig in spec["sequence"]:
                events.append(system.process(sig))
        else:
            intervention = spec.get("intervention", "none")
            events.append(system.process(spec["signal"], intervention=intervention))
        results.append({
            "scenario_id": spec["scenario_id"],
            "title": spec["title"],
            "hypothesis": spec["hypothesis"],
            "events": events,
            "final_state": system.state_snapshot(),
            "memories": [asdict(m) for m in system.memories],
        })
    package = {
        "system": SYSTEM_NAME,
        "version": VERSION,
        "seed": seed,
        "result_count": len(results),
        "results": results,
    }
    package["result_hash"] = stable_hash(package)
    return package


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--demo", action="store_true", help="run all built-in scenarios")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args(argv)
    result = run_demo(seed=args.seed)
    text = json.dumps(result, ensure_ascii=False, indent=2 if args.pretty else None, sort_keys=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
