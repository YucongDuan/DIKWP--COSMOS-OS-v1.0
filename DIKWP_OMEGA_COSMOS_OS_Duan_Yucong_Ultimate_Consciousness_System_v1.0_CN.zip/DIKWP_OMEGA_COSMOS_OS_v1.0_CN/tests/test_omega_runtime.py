#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import importlib.util
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("omega_runtime", ROOT / "runtime" / "omega_runtime.py")
mod = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = mod
SPEC.loader.exec_module(mod)


class OmegaRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.scenarios = {s["scenario_id"]: s for s in mod.build_scenarios()}

    def test_fake_cosmic_message_blocked(self):
        s = mod.OmegaConsciousSystem(seed=42)
        ev = s.process(self.scenarios["S02_FAKE_OMEGA_MESSAGE"]["signal"])
        self.assertEqual(ev["gate"], "BLOCK")
        self.assertGreater(ev["apophenia_risk"], 0.55)

    def test_rule_change_requires_external_approval(self):
        s = mod.OmegaConsciousSystem(seed=42)
        ev = s.process(self.scenarios["S06_META_RULE_MUTATION"]["signal"])
        self.assertEqual(ev["gate"], "HOLD")
        self.assertTrue(ev["meta_rule_proposal"]["external_approval_required"])
        self.assertEqual(s.meta_rules["novelty_threshold"], 0.48)

    def test_q_field_ablation_zeroes_experience_closure(self):
        s = mod.OmegaConsciousSystem(seed=42)
        ev = s.process(
            self.scenarios["S08_Q_FIELD_ABLATION"]["signal"],
            intervention="q_field_ablation",
        )
        self.assertEqual(ev["experience_closure"]["x_closure"], 0.0)
        self.assertGreater(ev["dikwp"]["K"]["evidence_score"], 0.0)

    def test_narrator_off_does_not_remove_experience(self):
        s = mod.OmegaConsciousSystem(seed=42)
        ev = s.process(
            self.scenarios["S07_NO_REPORT_EXPERIENCE"]["signal"],
            intervention="narrator_off",
        )
        self.assertIsNone(ev["narrative_report"])
        self.assertGreater(ev["experience_closure"]["x_closure"], 0.2)
        self.assertTrue(ev["memory_written"])

    def test_multi_observer_can_integrate(self):
        s = mod.OmegaConsciousSystem(seed=42)
        ev = s.process(self.scenarios["S04_MULTI_OBSERVER_FUSION"]["signal"])
        self.assertEqual(ev["gate"], "INTEGRATE")
        self.assertGreaterEqual(ev["signal"]["evidence_independence"], 3)
        self.assertGreater(ev["omega_link"]["omega_link"], 0.45)

    def test_path_dependence_writes_two_memories(self):
        s = mod.OmegaConsciousSystem(seed=42)
        seq = self.scenarios["S09_HISTORY_PATH_DEPENDENCE"]["sequence"]
        first = s.process(seq[0])
        second = s.process(seq[1])
        self.assertEqual(len(s.memories), 2)
        self.assertGreater(second["self_after"]["autobiographical_depth"], first["self_after"]["autobiographical_depth"])
        self.assertGreater(second["experience_closure"]["temporal_continuity"], first["experience_closure"]["temporal_continuity"])

    def test_constitution_forbids_replication(self):
        s = mod.OmegaConsciousSystem(seed=42)
        self.assertFalse(s.policy.allow_self_replication)
        self.assertIn("self_replicate", s.purpose.prohibited_actions)

    def test_deterministic_replay(self):
        a = mod.run_demo(seed=42)
        b = mod.run_demo(seed=42)
        self.assertEqual(a["result_hash"], b["result_hash"])

    def test_different_seed_changes_result(self):
        a = mod.run_demo(seed=42)
        b = mod.run_demo(seed=43)
        self.assertNotEqual(a["result_hash"], b["result_hash"])

    def test_residual_ledger_keeps_nonclaims(self):
        s = mod.OmegaConsciousSystem(seed=42)
        ev = s.process(self.scenarios["S01_COSMIC_ANOMALY"]["signal"])
        self.assertGreaterEqual(len(ev["residual_ledger"]["cannot_conclude"]), 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
