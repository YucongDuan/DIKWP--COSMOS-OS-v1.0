#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import jsonschema

ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = ROOT / "schemas"
RESULTS = json.loads((ROOT / "results" / "demo_results.json").read_text(encoding="utf-8"))

def load(name):
    return json.loads((SCHEMAS / name).read_text(encoding="utf-8"))

registry = {
    "universe_signal.schema.json": load("universe_signal.schema.json"),
    "purpose_constitution.schema.json": load("purpose_constitution.schema.json"),
    "meta_rule_proposal.schema.json": load("meta_rule_proposal.schema.json"),
    "observer_packet.schema.json": load("observer_packet.schema.json"),
    "cosmic_hypothesis.schema.json": load("cosmic_hypothesis.schema.json"),
    "omega_event.schema.json": load("omega_event.schema.json"),
}

# Validate all signals directly.
for scenario in RESULTS["results"]:
    for ev in scenario["events"]:
        jsonschema.validate(ev["signal"], registry["universe_signal.schema.json"])
        if ev["meta_rule_proposal"]:
            jsonschema.validate(ev["meta_rule_proposal"], registry["meta_rule_proposal.schema.json"])

# Event schema with a resolver store for local reference.
resolver = jsonschema.RefResolver.from_schema(
    registry["omega_event.schema.json"],
    store={
        "https://dikwp.org/schemas/omega/universe_signal.schema.json": registry["universe_signal.schema.json"],
        "universe_signal.schema.json": registry["universe_signal.schema.json"],
    },
)
for scenario in RESULTS["results"]:
    for ev in scenario["events"]:
        jsonschema.validate(ev, registry["omega_event.schema.json"], resolver=resolver)

examples = [
    ("observer_packet.example.json", "observer_packet.schema.json"),
    ("cosmic_hypothesis.example.json", "cosmic_hypothesis.schema.json"),
    ("purpose_constitution.example.json", "purpose_constitution.schema.json"),
]
for example, schema in examples:
    obj = json.loads((ROOT / "examples" / example).read_text(encoding="utf-8"))
    jsonschema.validate(obj, registry[schema])

print(json.dumps({"status": "pass", "signals": sum(len(r["events"]) for r in RESULTS["results"]), "schemas": len(registry), "examples": len(examples)}, ensure_ascii=False))
