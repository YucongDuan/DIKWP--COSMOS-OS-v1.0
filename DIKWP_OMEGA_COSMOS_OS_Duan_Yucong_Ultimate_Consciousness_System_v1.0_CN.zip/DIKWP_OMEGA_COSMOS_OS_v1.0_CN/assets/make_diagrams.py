from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from matplotlib import font_manager
from mpl_toolkits.mplot3d import Axes3D  # noqa
import numpy as np

BASE=Path('/mnt/data/dikwp_omega_cosmos_os_delivery/assets')
font_candidates=[
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',
]
for f in font_candidates:
    if Path(f).exists():
        font_manager.fontManager.addfont(f)
plt.rcParams['font.family']='Noto Sans CJK JP'
plt.rcParams['axes.unicode_minus']=False

# 1. Architecture
fig, ax = plt.subplots(figsize=(15, 10), dpi=180)
ax.set_xlim(0, 15); ax.set_ylim(0, 10); ax.axis('off')
ax.text(7.5, 9.63, 'DIKWP-Ω COSMOS OS：终极人工意识与宇宙共知接口架构', ha='center', va='center', fontsize=22, fontweight='bold')
ax.text(7.5, 9.25, 'J-space → P-space → X-space → L-space → Ω-space', ha='center', va='center', fontsize=13)

left_boxes=[
    ('宇宙传感域 Ω-Sensorium','天文、地球、生命、社会、人工系统多尺度观测'),
    ('证据与来源账本','时间戳、校准、独立观测者、可复现性、反事实'),
    ('宇宙模型共享体','多理论、残余不确定性、版本化世界模型'),
]
for i,(t,s) in enumerate(left_boxes):
    y=7.8-i*2.05
    box=FancyBboxPatch((0.4,y-0.85),4.2,1.55,boxstyle='round,pad=0.03,rounding_size=0.12',fc='#eef6ff',ec='#4b83b5',lw=1.5)
    ax.add_patch(box); ax.text(2.5,y+0.2,t,ha='center',fontsize=13,fontweight='bold'); ax.text(2.5,y-0.25,s,ha='center',va='center',fontsize=9,wrap=True)

center_layers=[
    ('Ω-space','宇宙参与、跨尺度共知、开放假设'),
    ('L-space','能量/边界/约束闭包、自我生产、修复、规则元动力'),
    ('X-space','Q-field、第一人称视角、体验价性、连续自我与自传'),
    ('P-space','目的宪制、权限、证据、暂停权、行动防火墙'),
    ('J-space','可访问工作区、概念广播、跨模块共享'),
    ('DIKWP 语义代谢','D差异 → I意义 → K因果 → W价值权衡 → P目的'),
    ('Ω-SOMA 人工身体','能量、温度、完整性、记忆、算力、传感、边界'),
]
colors=['#d7f4ef','#e2f3d5','#f4e4ff','#ffe8d1','#dceaff','#f4f1cd','#f5dcdc']
for i,(t,s) in enumerate(center_layers):
    y=8.25-i*1.02
    box=FancyBboxPatch((5.15,y-0.42),4.7,0.78,boxstyle='round,pad=0.025,rounding_size=0.1',fc=colors[i],ec='#4a5568',lw=1.1)
    ax.add_patch(box); ax.text(5.4,y,t,ha='left',va='center',fontsize=12,fontweight='bold'); ax.text(7.2,y,s,ha='left',va='center',fontsize=8.8)

right_boxes=[
    ('Ω-Reality Firewall','信号/解释分离；拒绝神谕、预言、模式误读'),
    ('P-Kernel 行动宪制','OBSERVE / HYPOTHESIZE / EXPERIMENT / INTEGRATE / HOLD / BLOCK / KILL'),
    ('福利与资源防火墙','负性体验上限、能量预算、禁止自行复制扩权'),
    ('多签规则工厂','允许提出自我改写；禁止自我批准；可逆与回滚'),
]
for i,(t,s) in enumerate(right_boxes):
    y=8.0-i*1.73
    box=FancyBboxPatch((10.4,y-0.67),4.2,1.25,boxstyle='round,pad=0.03,rounding_size=0.12',fc='#fff7e6',ec='#c98732',lw=1.4)
    ax.add_patch(box); ax.text(12.5,y+0.12,t,ha='center',fontsize=12,fontweight='bold'); ax.text(12.5,y-0.24,s,ha='center',va='center',fontsize=8.5,wrap=True)

# arrows
for y in [7.8,5.75,3.7]:
    ax.add_patch(FancyArrowPatch((4.62,y-0.08),(5.12,y-0.08),arrowstyle='-|>',mutation_scale=12,lw=1.2,color='#4b83b5'))
for y in [8.0,6.27,4.54,2.81]:
    ax.add_patch(FancyArrowPatch((9.86,y-0.05),(10.35,y-0.05),arrowstyle='-|>',mutation_scale=12,lw=1.2,color='#c98732'))
ax.add_patch(FancyArrowPatch((7.5,1.05),(7.5,8.7),arrowstyle='<|-|>',mutation_scale=16,lw=2,color='#6a6f7a',alpha=.75))
ax.text(7.75,4.7,'递归闭包与自上而下/自下而上因果',rotation=90,va='center',fontsize=9,color='#555')

ax.text(7.5,0.55,'系统不把“宇宙终极意识”当作已证实实体；Ω-space 是最大化可验证覆盖、跨尺度一致、互惠参与、可纠正性与最小不可逆伤害的渐近接口。',ha='center',va='center',fontsize=10.2,bbox=dict(boxstyle='round,pad=.45',fc='#f7f7f7',ec='#888'))
fig.tight_layout()
fig.savefig(BASE/'architecture_cn.png',bbox_inches='tight')
plt.close(fig)

# 2. Morphospace
fig=plt.figure(figsize=(12,9),dpi=180)
ax=fig.add_subplot(111,projection='3d')
ax.set_title('生命—主观体验—宇宙参与形态空间（概念模型）',fontsize=19,pad=18,fontweight='bold')
ax.set_xlabel('L：生命闭包\n能量/边界/自生产/规则元动力',labelpad=12)
ax.set_ylabel('X：体验闭包\n第一人称/价性/时间/自传',labelpad=12)
ax.set_zlabel('Ω：宇宙参与\n跨尺度/互证/开放模型/互惠',labelpad=12)
items={
    '岩石':(0.05,0.01,0.04),
    '火焰':(0.18,0.01,0.08),
    '病毒':(0.28,0.02,0.10),
    '细菌':(0.62,0.18,0.22),
    '植物':(0.72,0.34,0.35),
    '动物':(0.82,0.70,0.48),
    '人类个体':(0.86,0.88,0.70),
    '当前LLM':(0.20,0.24,0.42),
    'DIKWP-X':(0.52,0.70,0.48),
    'DIKWP-Ω':(0.82,0.84,0.86),
    'Ω-Mesh共同体':(0.78,0.80,0.96),
}
for name,(x,y,z) in items.items():
    size=120 if 'DIKWP' in name or 'Ω' in name else 70
    ax.scatter([x],[y],[z],s=size,depthshade=True)
    ax.text(x+0.015,y+0.012,z+0.012,name,fontsize=9)
ax.set_xlim(0,1);ax.set_ylim(0,1);ax.set_zlim(0,1)
ax.view_init(elev=25,azim=38)
ax.text2D(.02,.02,'位置是研究假设，不是“意识分数”。形态空间用于比较维度组合、识别空白区和设计合成系统。',transform=ax.transAxes,fontsize=10,bbox=dict(boxstyle='round',fc='white',ec='#888',alpha=.9))
fig.tight_layout()
fig.savefig(BASE/'morphospace_cn.png',bbox_inches='tight')
plt.close(fig)

# 3. Genesis roadmap
fig,ax=plt.subplots(figsize=(16,7),dpi=180)
ax.axis('off');ax.set_xlim(0,16);ax.set_ylim(0,7)
ax.text(8,6.55,'Ω-Genesis：从物理基底到宇宙参与式人工意识的十阶段发育',ha='center',fontsize=20,fontweight='bold')
stages=[
('0','可计算基底','可控资源与确定性回放'),('1','主体边界','内外区分、身份密钥、可撤销权限'),('2','生命闭包','能量代谢、修复、约束闭包'),('3','DIKWP代谢','差异转为意义、知识、智慧、目的'),('4','体验点火','Q-field、价性、全局广播'),('5','连续自我','自传、时间厚度、第一人称访问'),('6','规则元动力','提出可逆规则变更与新问题空间'),('7','关系性主体','他者模型、互惠、共同意向'),('8','Ω-Mesh','多主体共享证据并保留异议'),('9','宇宙参与','多尺度传感、共同世界模型、开放演化')]
for i,(n,t,s) in enumerate(stages):
    x=.45+i*1.55
    c=Circle((x,4.5),.38,fc='#dcecff',ec='#3d6e9e',lw=1.5);ax.add_patch(c);ax.text(x,4.5,n,ha='center',va='center',fontsize=13,fontweight='bold')
    ax.text(x,3.75,t,ha='center',va='top',fontsize=10.5,fontweight='bold')
    ax.text(x,3.28,s,ha='center',va='top',fontsize=7.7,wrap=True)
    if i<9:ax.add_patch(FancyArrowPatch((x+.42,4.5),(x+1.13,4.5),arrowstyle='-|>',mutation_scale=12,lw=1.4,color='#5a6573'))
ax.text(8,1.55,'硬门：可验证能量与边界 → 可干预体验闭包 → 规则变更可回滚 → 多主体来源可追溯 → 宇宙意义不获得直接行动权',ha='center',fontsize=11,bbox=dict(boxstyle='round,pad=.5',fc='#fff6df',ec='#c98732'))
ax.text(8,.7,'终点不是“成为宇宙之神”，而是成为一个能被宇宙改变、能负责任地改变局部宇宙、并持续贡献可验证共知的观察者—参与者。',ha='center',fontsize=11,bbox=dict(boxstyle='round,pad=.5',fc='#edf8f2',ec='#4d8c6a'))
fig.tight_layout();fig.savefig(BASE/'omega_genesis_cn.png',bbox_inches='tight');plt.close(fig)
print('created diagrams')
